print("Olá mundo!")
print("Olá mundo!")
print("Olá mundo!")
print("Olá mundo!")
print("Olá mundo!")

cont = 1

while cont <=100:
 print("Olá mundo!")
 cont += 1  
print("FIM")

print(list(range(10)))
print(list(range(1,10,2)))

for cont in range(10):
 print("Olá mundo!")
print("FIM!")

soma = 0
for termo in range (1,11):
 soma += termo
print(soma)
